const { Router } = require('express');
const fs = require('fs');
const router = Router();

//Get
router.get('/getCourses', (req, res) => {
    try{
        const jsonString = fs.readFileSync('src/db.json', 'utf-8');
        const data = JSON.parse(jsonString);
        res.json(data);
    }catch(err){
        console.log(err);
    }
});

//post
router.post('/addCourses', (req, res) => {
    const {curso, codigo, nota} = req.body;

    if(curso && codigo && nota){
        const newObject =
        {
            curso: curso,
            codigo: codigo,
            nota: nota
        }
        try{
            const jsonString = fs.readFileSync('src/db.json', 'utf-8');
            const data = JSON.parse(jsonString);
            data.push(newObject);
            const jsonData = JSON.stringify(data, null, 2);
            fs.writeFile('src/db.json', jsonData, err =>{
                if(err){
                    console.log(err);
                }
                else{
                    console.log('OK');
                    res.send('OK requets');
                }
            });
        }catch(err){
            console.log(err);
        }
    }
    else{
        res.send('Data missing');
    }
});

//PUT - UPDATE
router.put('/updateCourse/:key', (req, res) => {
    const {curso, codigo, nota} = req.body;
    const { key } = req.params;

    if(curso && codigo && nota){
        try
        {
            const jsonString = fs.readFileSync('src/db.json', 'utf-8');
            const data = JSON.parse(jsonString);

            data.forEach(element => {
                if(element.codigo == key){
                    element.curso = curso;
                    element.nota = nota;
                }
            });
            const jsonData = JSON.stringify(data, null, 2);
            fs.writeFile('src/db.json', jsonData, err => {
                if(err){
                    console.log(err);
                }else{
                    console.log('Update success');
                    res.send('Update OK');
                }
            });
        }catch(err){
            console.log(err);
        }
    }else{
        res.send('Attributes missing');
    }
});

//Delete
router.delete('deleteCourse/:key', (req, res) => {
    const { key } = req.params;
    try{
        const jsonString = fs.readFileSync('src/db.json', 'utf-8');
        const data = JSON.parse(jsonString);

        for(var i = 0; i < data.length; i++){
            if(data[i].codigo == key){
                data.splice(i, 1);
            }
        }
        const jsonData = JSON.stringify(data, null, 2);
        fs.writeFile('src/db.json', jsonData, err => {
            if(err){
                console.log(err);
            }
            else{
                res.send('Delete OK');
            }
        });
    }catch(err){
        console.log(err);
    }
});

module.exports = router;